class Url{
  static const String exchangeBaseUrl = 'https://api.exchangeratesapi.io/';
}
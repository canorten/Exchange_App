import 'package:flutter/material.dart';

// App's main colors
const primaryColor = const Color(0xFF3783F5);
const primaryGrey = const Color(0xFFEDF1F9);
